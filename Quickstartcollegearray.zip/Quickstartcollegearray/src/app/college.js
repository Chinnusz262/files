"use strict";
//# sourceMappingURL=college.js.map