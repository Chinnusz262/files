import {Component, OnInit} from '@angular/core';
import {College} from "./college";
import {CollegeService} from './collegeservice';
import { CollegeComponent} from './collegecomponent';

@Component({
selector:'collegeAddComponent',
templateUrl:'./collegeaddcomponent.html',                                     //setting template
providers:[CollegeService],
})
export class CollegeAddComponent implements OnInit{
    id:number;
    name:string;
    state:string;
   
	public c:CollegeComponent;
    colleges:College[];
    
	constructor(private collegeService:CollegeService){}                    //creating service object
    ngOnInit(){
	  this.colleges=this.collegeService.getColleges();
	 	
    } 

  // ===============================delete row function==============================================
    delete(obj:College)
    {
      var index=this.colleges.indexOf(obj);
      this.colleges.splice(index,1);
    }


    //===========================Addind Employee Details Function==========================================
    addData():void
    {
			
		  if(this.id!=null&&this.name!=null&&this.state!=null)
		  {
			  let e:College={id:this.id,name:this.name,state:this.state};
			 this.colleges.push(e);       // to add Data to employee array
    
		  }
      else{
		    alert("insert data")
      }
    }
 //===============================sort=============================================
sortById(): void 
  {
    this.colleges.sort((a,b)=>a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  }
//method for sorting college Name
  sortByName(): void 
  {
    this. colleges.sort((a,b)=>a.name < b.name ? -1 : a.name > b.name ? 1 : 0);
  }

	
	
	
  

 
     }
 
