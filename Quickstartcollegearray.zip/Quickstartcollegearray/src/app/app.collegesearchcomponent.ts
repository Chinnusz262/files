import {Component, OnInit} from '@angular/core';
import {College} from './college';
import { ActivatedRoute,Router, Params } from '@angular/router';
@Component({
    
    template:'<h1>In search{{collegeCode}}</h1>'
})
export class CollegeSearchComponent implements OnInit{
    
    collegeCode:string;
//getting data from URL
    ngOnInit(): void {
        this.collegeCode=this._activate.snapshot.params['id'];
    }
   constructor(private _activate:ActivatedRoute) {
	
}
   
}