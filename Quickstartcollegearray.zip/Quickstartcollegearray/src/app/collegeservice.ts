
import {College} from './college';
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Response } from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()                                          
export class CollegeService{
 
 getColleges():College[]{

        return[
            {id:1001,	name:'IIT',	state:'Pune'},
            {id:1002,	name:'IIM',	state:'Mumbai'},
            {id:1009,	name:'Cusat', state:'Kerala'}
        ];
    }
 
}


 