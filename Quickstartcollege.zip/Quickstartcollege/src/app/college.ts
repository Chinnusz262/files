export interface College{
    id:number;
    name:string;
    state:string;
    
}