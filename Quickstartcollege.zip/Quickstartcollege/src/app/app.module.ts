import  { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';                                    //necessary imports
import { AppComponent }  from './app.component';
import { CollegeComponent }  from './collegecomponent';
import {CollegeService} from './collegeservice';
import {HttpModule} from '@angular/http';
import {FormsModule} from '@angular/forms';
import {CollegeAddComponent }  from './collegeaddcomponent';
import {Routes, RouterModule} from '@angular/router';
import { CollegeSearchComponent }  from './app.collegesearchcomponent';
																							   //to redirect to getdata page
const appRoutes: Routes=[																	
                   { path: '', redirectTo:'/getdata',pathMatch: 'full'},
                  { path: 'getdata',  component: CollegeComponent},  				  
				  { path: 'adddata',  component: CollegeAddComponent},  
                   {path:'search/:id',component:CollegeSearchComponent}
				   ];
@NgModule({
  imports:      [ BrowserModule,RouterModule.forRoot(appRoutes),  HttpModule, FormsModule],     //importing modules
  declarations: [ AppComponent, CollegeComponent, CollegeSearchComponent, CollegeAddComponent],                                            //declaring components          
  bootstrap:    [ AppComponent ],
})

export class AppModule {}