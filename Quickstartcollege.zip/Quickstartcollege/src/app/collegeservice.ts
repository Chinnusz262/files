
import {College} from './college';
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Response } from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
@Injectable()                                                       //decorator for service
export class CollegeService{
 constructor(private http:Http) {}
	public getJSON():Observable<College[]>{
         
			return this.http.get('/app/college.json').map((response:Response)=><College[]>response.json());
    }
}


 