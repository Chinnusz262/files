export interface Mobile{
mobileId:number;
mobileName:string;
mobilePrice:number;
mobileBrand:string;
}