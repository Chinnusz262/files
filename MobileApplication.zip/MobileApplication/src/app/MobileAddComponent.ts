import {Component,OnInit} from '@angular/core';
import {Mobile} from './Mobile';
import {MobileService} from './MobileService';

@Component({
selector:'app-MobileaddComponent',
templateUrl:'./MobileAddComponent.html',
 providers:[MobileService]
})
export class  MobileAddComponent implements  OnInit {
Mobiles:Mobile[];
constructor(private mobileservice:MobileService) { }
ngOnInit(): void {
    this.Mobiles=this.mobileservice.getAllMobile();
}
mobileId:number;
mobileName:string;
mobilePrice:number;
mobileBrand:string;
addData():void{
if(this.mobileId!=null&&this.mobileName!=null&&this.mobilePrice!=null&&this.mobileBrand!=null){
let mobile:Mobile={mobileId:this.mobileId,mobileName:this.mobileName,mobilePrice:this.mobilePrice,mobileBrand:this.mobileBrand};
this.Mobiles.push(mobile);
alert("data inserted");
}
else{
alert("no data inserted");
}
}

deleteData(obj:Mobile)
{
var index=this.Mobiles.indexOf(obj);
this.Mobiles.splice(index,1);
}
}