import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {MobileComponent} from './MobileComponent';
import { AppComponent }  from './app.component';
import { FormsModule }  from '@angular/forms';
import {Routes, RouterModule} from '@angular/router';
import {MobileAddComponent} from './MobileAddComponent';
const appRoutes: Routes=[
                     { path: ' ',  redirectTo:'/getdata',pathMatch: 'full'},
                     { path: 'getdata',  component: MobileComponent},
                     { path: 'postdata',  component: MobileAddComponent }
                    
                      ];
@NgModule({
  imports:      [ BrowserModule, FormsModule,RouterModule.forRoot(appRoutes)],
  declarations: [ AppComponent,MobileComponent,MobileAddComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
