import { Injectable }      from '@angular/core';
import {Mobile} from './Mobile';
@Injectable()//specifying it as service
export class MobileService{
getAllMobile():Mobile[] 
{ return [
{ mobileId: 1003, mobileName: "Samsung", mobilePrice: 5000, mobileBrand: "samsung" },
{mobileId : 1004, mobileName: "Apple", mobilePrice: 6000,mobileBrand : "Apple" },

];
}
}