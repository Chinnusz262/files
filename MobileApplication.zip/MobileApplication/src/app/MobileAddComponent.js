"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var MobileService_1 = require("./MobileService");
var MobileAddComponent = (function () {
    function MobileAddComponent(mobileservice) {
        this.mobileservice = mobileservice;
    }
    MobileAddComponent.prototype.ngOnInit = function () {
        this.Mobiles = this.mobileservice.getAllMobile();
    };
    MobileAddComponent.prototype.addData = function () {
        if (this.mobileId != null && this.mobileName != null && this.mobilePrice != null && this.mobileBrand != null) {
            var mobile = { mobileId: this.mobileId, mobileName: this.mobileName, mobilePrice: this.mobilePrice, mobileBrand: this.mobileBrand };
            this.Mobiles.push(mobile);
            alert("data inserted");
        }
        else {
            alert("no data inserted");
        }
    };
    MobileAddComponent.prototype.deleteData = function (obj) {
        var index = this.Mobiles.indexOf(obj);
        this.Mobiles.splice(index, 1);
    };
    return MobileAddComponent;
}());
MobileAddComponent = __decorate([
    core_1.Component({
        selector: 'app-MobileaddComponent',
        templateUrl: './MobileAddComponent.html',
        providers: [MobileService_1.MobileService]
    }),
    __metadata("design:paramtypes", [MobileService_1.MobileService])
], MobileAddComponent);
exports.MobileAddComponent = MobileAddComponent;
//# sourceMappingURL=MobileAddComponent.js.map