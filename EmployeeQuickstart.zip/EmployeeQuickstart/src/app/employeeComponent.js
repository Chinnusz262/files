"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var employeeService_1 = require("./employeeService");
var EmployeeComponent = (function () {
    function EmployeeComponent(employeeService) {
        this.employeeService = employeeService;
    }
    EmployeeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.employeeService.getJSON().subscribe(function (employeesData) { return _this.employees = employeesData; });
    };
    // ===============================delete row function==============================================
    EmployeeComponent.prototype.delete = function (obj) {
        var index = this.employees.indexOf(obj);
        this.employees.splice(index, 1);
    };
    //===========================Addind Employee Details Function==========================================
    EmployeeComponent.prototype.addData = function () {
        if (this.id != null && this.name != null && this.salary != null && this.department != null && this.dateOfJoining != null) {
            var e = { id: this.id, name: this.name, salary: this.salary, department: this.department, dateOfJoining: this.dateOfJoining };
            this.employees.push(e); // to add Data to employee array
        }
        else {
            alert("insert data");
        }
    };
    //===============================sort=============================================
    EmployeeComponent.prototype.sortById = function () {
        this.employees.sort(function (a, b) { return a.id < b.id ? -1 : a.id > b.id ? 1 : 0; });
    };
    //method for sorting college Name
    EmployeeComponent.prototype.sortByName = function () {
        this.employees.sort(function (a, b) { return a.name < b.name ? -1 : a.name > b.name ? 1 : 0; });
    };
    return EmployeeComponent;
}());
EmployeeComponent = __decorate([
    core_1.Component({
        selector: 'employee-Component',
        templateUrl: './employeecomponent.html',
        providers: [employeeService_1.EmployeeService],
    }),
    __metadata("design:paramtypes", [employeeService_1.EmployeeService])
], EmployeeComponent);
exports.EmployeeComponent = EmployeeComponent;
//# sourceMappingURL=employeeComponent.js.map