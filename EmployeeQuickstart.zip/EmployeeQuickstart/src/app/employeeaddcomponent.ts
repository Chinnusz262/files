import {Component, OnInit} from '@angular/core';
import {Employee} from "./employee";
import {EmployeeService} from './employeeService';


@Component({
selector:'employeeAddComponent',
templateUrl:'./employeeaddcomponent.html',                                     //setting template
providers:[EmployeeService],
})
export class EmployeeAddComponent implements OnInit{
    id:number;
    name:string;
    salary:number;
    department:string;
    dateOfJoining:string;
	
    employees:Employee[];
    
	constructor(private employeeService:EmployeeService){}                    //creating service object
    ngOnInit(){
	  	this.employeeService.getJSON().subscribe((employeesData)=>this.employees=employeesData);
	 	
    } 

	 addData():void
    {
		  if(this.id!=null&&this.name!=null&&this.salary!=null&&this.department!=null&&this.dateOfJoining!=null)
		  {
			  let e:Employee={id:this.id,name:this.name,salary:this.salary,department:this.department,dateOfJoining:this.dateOfJoining};
			  this.employees.push(e);       // to add Data to employee array
			
			
		  }
      else{
		    alert("insert data")
      }
    }
	
	
}