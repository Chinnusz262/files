import {Component, OnInit} from '@angular/core';
import {Employee} from "./employee";
import {EmployeeService} from './employeeService';


@Component({
selector:'employee-Component',
templateUrl:'./employeecomponent.html',                                     //setting template
providers:[EmployeeService],
})
export class EmployeeComponent implements OnInit{
    id:number;
    name:string;
    salary:number;
    department:string;
    dateOfJoining:string;
	
    employees:Employee[];
    
	constructor(private employeeService:EmployeeService){}	
    ngOnInit(){
	  	this.employeeService.getJSON().subscribe((employeesData)=>this.employees=employeesData);
	 	
    } 

  // ===============================delete row function==============================================
    delete(obj:Employee)
    {
      var index=this.employees.indexOf(obj);
      this.employees.splice(index,1);
    }


    //===========================Addind Employee Details Function==========================================
    addData():void
    {
		  if(this.id!=null&&this.name!=null&&this.salary!=null&&this.department!=null&&this.dateOfJoining!=null)
		  {
			  let e:Employee={id:this.id,name:this.name,salary:this.salary,department:this.department,dateOfJoining:this.dateOfJoining};
			  this.employees.push(e);       // to add Data to employee array
    
		  }
      else{
		    alert("insert data")
      }
    }
 //===============================sort=============================================
sortById(): void 
  {
    this.employees.sort((a,b)=>a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  }
//method for sorting college Name
  sortByName(): void 
  {
    this. employees.sort((a,b)=>a.name < b.name ? -1 : a.name > b.name ? 1 : 0);
  }


 
     }
 
