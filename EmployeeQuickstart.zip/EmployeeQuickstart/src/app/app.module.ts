import  { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';                                    //necessary imports
import { AppComponent }  from './app.component';
import { EmployeeComponent }  from './employeeComponent';
import {EmployeeService} from './employeeservice';
import {HttpModule} from '@angular/http';
import {FormsModule} from '@angular/forms';
import {EmployeeAddComponent }  from './employeeAddComponent';
import {Routes, RouterModule} from '@angular/router';
import { EmployeeSearchComponent }  from './app.employeesearchcomponent';
																							   //to redirect to getdata page
const appRoutes: Routes=[																	
                  // { path: '', redirectTo:'/getdata',pathMatch: 'full'},
                  { path: 'getdata',  component: EmployeeComponent},              		
				  { path: 'adddata',  component: EmployeeAddComponent},  
                   {path:'search/:id',component:EmployeeSearchComponent}
				   ];
@NgModule({
  imports:      [ BrowserModule,RouterModule.forRoot(appRoutes),  HttpModule, FormsModule],     //importing modules
  declarations: [ AppComponent, EmployeeComponent, EmployeeSearchComponent, EmployeeAddComponent],                                            //declaring components          
  bootstrap:    [ AppComponent ],
})

export class AppModule {}