"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var employeeService_1 = require("./employeeService");
var AppEmployeeComponent = (function () {
    function AppEmployeeComponent() {
    }
    AppEmployeeComponent.prototype.getAllEmployees = function () {
        return [
            { id: 1001, name: 'Bharathi', salary: 9000, department: 'JAVA', dateOfJoining: '6/12/2014' },
            { id: 1002, name: 'Anju', salary: 11000, department: 'ORAAPS', dateOfJoining: '6/12/2017' },
            { id: 1003, name: 'Uma', salary: 12000, department: 'JAVA', dateOfJoining: '6/12/2010' },
            { id: 1004, name: 'Yogini', salary: 11500, department: 'ORAAPS', dateOfJoining: '11/12/2017' },
            { id: 1005, name: 'Tanmay', salary: 7000, department: '.NET', dateOfJoining: '1/1/2018' },
            { id: 1006, name: 'Kavitha', salary: 17000, department: 'BI', dateOfJoining: '9/12/2012' },
            { id: 1007, name: 'Rajitha', salary: 21000, department: 'BI', dateOfJoining: '6/7/2014' },
            { id: 1008, name: 'Neelima', salary: 81000, department: 'TESTING', dateOfJoining: '6/17/2015' },
            { id: 1009, name: 'Daya', salary: 1000, department: 'TESTING', dateOfJoining: '6/17/2016' }
        ];
    };
    return AppEmployeeComponent;
}());
AppEmployeeComponent = __decorate([
    core_1.Component({
        selector: 'Employee-Component1',
        templateUrl: './employeecomponent.html',
        providers: [employeeService_1.EmployeeService],
    })
], AppEmployeeComponent);
exports.AppEmployeeComponent = AppEmployeeComponent;
//# sourceMappingURL=AppEmployeeComponent.js.map