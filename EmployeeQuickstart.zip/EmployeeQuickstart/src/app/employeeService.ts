
import {Employee} from './employee';
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Response } from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
@Injectable()                                                       //decorator for service
export class EmployeeService{
 constructor(private http:Http) {}
	public getJSON():Observable<Employee[]>{
         
			return this.http.get('/app/booklist.json').map((response:Response)=><Employee[]>response.json());
    }
}


 